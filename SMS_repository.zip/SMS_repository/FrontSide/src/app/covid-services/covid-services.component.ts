import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covid-services',
  templateUrl: './covid-services.component.html',
  styleUrls: ['./covid-services.component.css']
})
export class CovidServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
